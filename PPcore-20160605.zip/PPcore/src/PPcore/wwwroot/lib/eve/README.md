# Eve

Tiny event helping JavaScript library.

MIT Licence

For use case look at e.html
