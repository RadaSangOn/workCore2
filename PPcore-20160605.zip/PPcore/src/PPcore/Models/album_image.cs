﻿using System;
using System.Collections.Generic;

namespace PPcore.Models
{
    public partial class album_image
    {
        public string album_code { get; set; }
        public string image_code { get; set; }
        public string x_status { get; set; }
        public string x_note { get; set; }
        public string x_log { get; set; }
    }
}
